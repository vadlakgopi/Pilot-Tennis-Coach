# Tennis Ball > 2025-02-25 8:44am
https://universe.roboflow.com/tennis-e47pp/tennis-ball-spwux

Provided by a Roboflow user
License: CC BY 4.0

